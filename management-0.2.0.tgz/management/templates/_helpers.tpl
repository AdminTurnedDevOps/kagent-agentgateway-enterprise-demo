{{/* Create a full image reference*/}}
{{- define "tunnel-server.image" -}}
{{- $registry := .Values.tunnelserver.registry }}
{{- $repository := .Values.tunnelserver.repository }}
{{- $name := .Values.tunnelserver.name }}
{{- $tag := coalesce .Values.tunnelserver.tag .Chart.Version }}
{{- printf "%s/%s/%s:%s" $registry $repository $name $tag }}
{{- end }}

{{- define "ui-backend.image" -}}
{{- $registry := .Values.ui.backend.registry }}
{{- $repository := .Values.ui.backend.repository }}
{{- $name := .Values.ui.backend.name }}
{{- $tag := coalesce .Values.ui.backend.tag .Chart.Version }}
{{- printf "%s/%s/%s:%s" $registry $repository $name $tag }}
{{- end }}

{{- define "ui-frontend.image" -}}
{{- $registry := .Values.ui.frontend.registry }}
{{- $repository := .Values.ui.frontend.repository }}
{{- $name := .Values.ui.frontend.name }}
{{- $tag := coalesce .Values.ui.frontend.tag .Chart.Version }}
{{- printf "%s/%s/%s:%s" $registry $repository $name $tag }}
{{- end }}

{{- define "ui-frontend.image-tag" -}}
{{- coalesce .Values.ui.frontend.tag .Chart.Version }}
{{- end }}

{{/* Create a full image reference for telemetrygateway */}}
{{- define "telemetrygateway.image" -}}
{{- $repository := default "otel/opentelemetry-collector-contrib" .Values.ui.telemetryGateway.repository }}
{{- $version := default "0.132.1" .Values.ui.telemetryGateway.version }}
{{- printf "%s:%s" $repository $version }}
{{- end }}

{{/* Chart name */}}
{{- define "kagent-enterprise.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Chart full name */}}
{{- define "kagent-enterprise.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := include "kagent-enterprise.name" . -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/* Common labels */}}
{{- define "kagent-enterprise.labels" -}}
app.kubernetes.io/name: {{ include "kagent-enterprise.name" . }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Render container resources block.
Usage: {{ include "solo-enterprise.resources" .Values.tunnelserver.resources }}
*/}}
{{- define "solo-enterprise.resources" -}}
{{- if and . (not (empty .)) }}
resources:
{{- if and .requests (not (empty .requests)) }}
  requests:
    cpu: "{{ .requests.cpu }}"
    memory: "{{ .requests.memory }}"
{{- end }}
{{- if and .limits (not (empty .limits)) }}
  limits:
    cpu: "{{ .limits.cpu }}"
    memory: "{{ .limits.memory }}"
{{- end }}
{{- end }}
{{- end }}

{{/*
Render probe configuration options (timing and thresholds).
Usage: {{ include "solo-enterprise.probeOptions" .Values.tunnelserver.livenessProbe }}
*/}}
{{- define "solo-enterprise.probeOptions" -}}
{{- if .initialDelaySeconds | empty | not }}
initialDelaySeconds: {{ .initialDelaySeconds }}
{{- end }}
{{- if .periodSeconds | empty | not }}
periodSeconds: {{ .periodSeconds }}
{{- end }}
{{- if .timeoutSeconds | empty | not }}
timeoutSeconds: {{ .timeoutSeconds }}
{{- end }}
{{- if .successThreshold | empty | not }}
successThreshold: {{ .successThreshold }}
{{- end }}
{{- if .failureThreshold | empty | not }}
failureThreshold: {{ .failureThreshold }}
{{- end }}
{{- end }}
