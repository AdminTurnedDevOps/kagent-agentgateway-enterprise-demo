# NOTE: This file is automatically loaded by the Bitnami ClickHouse chart at startup.
# It contains the full DDL needed for kagent-enterprise.
# ----------------------------------------------------------------------------
#!/bin/bash
clickhouse-client -u default --password password --multiquery <<SQL
-- JSON-based Logs table DDL to store input/output GenAI events.
CREATE TABLE IF NOT EXISTS otel_logs_json (
    Timestamp DateTime64(9) CODEC(Delta(8), ZSTD(1)),
    TimestampTime DateTime DEFAULT toDateTime(Timestamp),
    SpanId String CODEC(ZSTD(1)),
    TraceFlags UInt8,
    TraceId String CODEC(ZSTD(1)),
    SeverityText LowCardinality(String) CODEC(ZSTD(1)),
    SeverityNumber UInt8,
    ServiceName LowCardinality(String) CODEC(ZSTD(1)),
    Body String CODEC(ZSTD(1)),
    BodyJson JSON DEFAULT if(empty(Body), '{}', Body)::JSON,
    ResourceSchemaUrl LowCardinality(String) CODEC(ZSTD(1)),
    ResourceAttributes JSON CODEC(ZSTD(1)),
    ScopeSchemaUrl LowCardinality(String) CODEC(ZSTD(1)),
    ScopeName String CODEC(ZSTD(1)),
    ScopeVersion LowCardinality(String) CODEC(ZSTD(1)),
    ScopeAttributes JSON CODEC(ZSTD(1)),
    LogAttributes JSON CODEC(ZSTD(1)),

    INDEX idx_body Body TYPE tokenbf_v1(32768, 3, 0) GRANULARITY 8
) ENGINE = MergeTree()
PARTITION BY toDate(TimestampTime)
PRIMARY KEY (ServiceName, TimestampTime)
ORDER BY (ServiceName, TimestampTime, Timestamp)
TTL TimestampTime + toIntervalDay(180)
SETTINGS index_granularity = 8192, ttl_only_drop_parts = 1;

-- JSON-based Logs table DDL for k8sobjects.
CREATE TABLE IF NOT EXISTS otel_k8sobjects_json (
    Timestamp DateTime64(9) CODEC(Delta(8), ZSTD(1)),
    TimestampTime DateTime DEFAULT toDateTime(Timestamp),
    SpanId String CODEC(ZSTD(1)),
    TraceFlags UInt8,
    TraceId String CODEC(ZSTD(1)),
    SeverityText LowCardinality(String) CODEC(ZSTD(1)),
    SeverityNumber UInt8,
    ServiceName LowCardinality(String) CODEC(ZSTD(1)),
    Body String CODEC(ZSTD(1)),
    BodyJson JSON DEFAULT if(empty(Body), '{}', Body)::JSON,
    ResourceSchemaUrl LowCardinality(String) CODEC(ZSTD(1)),
    ResourceAttributes JSON CODEC(ZSTD(1)),
    ScopeSchemaUrl LowCardinality(String) CODEC(ZSTD(1)),
    ScopeName String CODEC(ZSTD(1)),
    ScopeVersion LowCardinality(String) CODEC(ZSTD(1)),
    ScopeAttributes JSON CODEC(ZSTD(1)),
    LogAttributes JSON CODEC(ZSTD(1)),

    INDEX idx_body Body TYPE tokenbf_v1(32768, 3, 0) GRANULARITY 8
) ENGINE = MergeTree()
PARTITION BY toDate(TimestampTime)
PRIMARY KEY (ServiceName, TimestampTime)
ORDER BY (ServiceName, TimestampTime, Timestamp)
TTL TimestampTime + toIntervalDay(180)
SETTINGS index_granularity = 8192, ttl_only_drop_parts = 1;

-- Create target table for otel_k8sobjects_json's Materialized View.
-- This is the schema we are storing k8sobjects in for optimized flexibility and querying.
CREATE TABLE IF NOT EXISTS otel_k8sobjects_table_json (
    TimeStamp DateTime64(9) CODEC(Delta, ZSTD(1)),
    Body JSON CODEC(ZSTD(1)),
    Managers Array(String) CODEC(ZSTD(1)),
    Uid UUID CODEC(ZSTD(1)),
    ApiVersion String CODEC(ZSTD(1)),
    CreationTimestamp DateTime64 CODEC(Delta, ZSTD(1)),
    Name String CODEC(ZSTD(1)),
    Namespace String CODEC(ZSTD(1)),
    ClusterName String CODEC(ZSTD(1)), -- Inject this from install-time values into Resource Attributes via a processor.
    Kind String CODEC(ZSTD(1)),
    Labels Map(LowCardinality(String), String) CODEC(ZSTD(1)),
    Annotations Map(LowCardinality(String), String) CODEC(ZSTD(1)),
    Spec JSON CODEC(ZSTD(1)),
    Status JSON CODEC(ZSTD(1)),
    EventType LowCardinality(String) CODEC(ZSTD(1)), -- K8s event type: ADDED, MODIFIED, DELETED
    Deleted UInt8, -- Used by ReplacingMergeTree.
    ResourceVersion UInt64, -- Used by ReplacingMergeTree.

    INDEX idx_res_labels_key mapKeys(Labels) TYPE bloom_filter(0.01) GRANULARITY 1,
    INDEX idx_res_labels_value mapValues(Labels) TYPE bloom_filter(0.01) GRANULARITY 1,
    INDEX idx_res_annotations_key mapKeys(Annotations) TYPE bloom_filter(0.01) GRANULARITY 1,
    INDEX idx_res_annotatons_value mapValues(Annotations) TYPE bloom_filter(0.01) GRANULARITY 1,

) ENGINE = ReplacingMergeTree(ResourceVersion, Deleted)
PARTITION BY toDate(TimeStamp)
PRIMARY KEY (ClusterName, Uid)
ORDER BY (ClusterName, Uid, Namespace, Kind, Name)
TTL toDate(TimeStamp) + toIntervalDay(180)
SETTINGS index_granularity=8192, ttl_only_drop_parts = 1;

-- Materialized View to populate our custom schema called `otel_k8sobjects_table_json` after writing into `otel_k8sobjects_json`.
CREATE MATERIALIZED VIEW otel_k8sobjects_table_json_mv TO otel_k8sobjects_table_json AS
    SELECT
        TimestampTime AS TimeStamp,
        Body.object.metadata.managedFields[].manager::Array(String) AS Managers,
        Body.object.kind::String AS Kind,
        JSONExtractKeysAndValuesRaw(Body.^object.metadata.labels::String) AS Labels,
        JSONExtractKeysAndValuesRaw(Body.^object.metadata.annotations::String) AS Annotations,
        parseDateTimeBestEffort(Body.object.metadata.creationTimestamp) AS CreationTimestamp,
        Body.object.metadata.name::String AS Name,
        Body.object.metadata.namespace::String AS Namespace,
        ResourceAttributes.cluster_name::String AS ClusterName,
        Body.object.metadata.uid::String AS Uid,
        Body.object.apiVersion::String AS ApiVersion,
        Body.object.metadata.resourceVersion::String AS ResourceVersion,
        -- Add all frequently queried fields below this comment (driving UI panels)
        -- The examples bewlo are CRD-specific, so we might be better off starting with the wildcard fields
        -- Body.object.spec.description::String AS Description,
        -- Body.object.spec.modelConfig::String AS ModelConfig, -- Agent
        -- Body.object.spec.provider::String AS ModelConfig, -- Memory
        -- Add all wildcard fields below this comment (might be extracted later into columns)
        Body.^object.spec::JSON AS Spec, -- This might get expensive, but it works!
        Body.^object.status::JSON AS Status, -- This might get expensive, but it works!
        -- EXTRACT K8S EVENT TYPE: ADDED, MODIFIED, DELETED
        Body.type::String AS EventType
    FROM (SELECT TimestampTime, BodyJson::JSON as Body, ResourceAttributes FROM otel_k8sobjects_json);

-- Default Trace table DDL leveraging JSON
CREATE TABLE IF NOT EXISTS otel_traces_json (
    Timestamp DateTime64(9) CODEC(Delta, ZSTD(1)),
    TraceId String CODEC(ZSTD(1)),
    SpanId String CODEC(ZSTD(1)),
    ParentSpanId String CODEC(ZSTD(1)),
    TraceState String CODEC(ZSTD(1)),
    SpanName LowCardinality(String) CODEC(ZSTD(1)),
    SpanKind LowCardinality(String) CODEC(ZSTD(1)),
    ServiceName LowCardinality(String) CODEC(ZSTD(1)),
    ResourceAttributes JSON CODEC(ZSTD(1)),
    ScopeName String CODEC(ZSTD(1)),
    ScopeVersion String CODEC(ZSTD(1)),
    SpanAttributes JSON CODEC(ZSTD(1)),
    Duration UInt64 CODEC(ZSTD(1)),
    StatusCode LowCardinality(String) CODEC(ZSTD(1)),
    StatusMessage String CODEC(ZSTD(1)),
    Events Nested (
        Timestamp DateTime64(9),
        Name LowCardinality(String),
        Attributes JSON
    ) CODEC(ZSTD(1)),
    Links Nested (
        TraceId String,
        SpanId String,
        TraceState String,
        Attributes JSON
    ) CODEC(ZSTD(1)),
    INDEX idx_duration Duration TYPE minmax GRANULARITY 1
) ENGINE = MergeTree()
PARTITION BY toDate(Timestamp)
ORDER BY (ServiceName, SpanName, toDateTime(Timestamp), Timestamp)

TTL toDate(Timestamp) + toIntervalDay(90)
SETTINGS index_granularity=8192, ttl_only_drop_parts = 1;
SQL


