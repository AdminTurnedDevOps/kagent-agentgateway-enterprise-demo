<img src="https://img.shields.io/badge/Version-0.1.10-informational?style=flat-square" alt="Version: 0.1.10" align="left">

<br>Review Helm values for the Solo Enterprise for kagent `management` Helm chart.

## Overview

The management chart deploys the core Solo Enterprise for kagent components including:
- UI frontend
- UI backend gRPC/REST API server
- Tunnel server for secure communication with workload clusters
- OpenTelemetry gateway for telemetry aggregation
- ClickHouse database for data storage

For more information, see the [installation guide](https://docs.solo.io/kagent-enterprise/docs/latest/install/install/#kagent-ent).

### OIDC configuration

{{< callout type="info" >}}
The fields that configure OIDC details default to values for the [demo installation of Keycloak](https://docs.solo.io/kagent-enterprise/docs/latest/quickstart/), which you can deploy as part of the getting started guide. To use any IdP other than this local demo instance, you **must** change these values to your own details. For more information, see [Identity providers](https://docs.solo.io/kagent-enterprise/docs/latest/install/idp/).
{{< /callout >}}

### ClickHouse performance configuration

The following default values are set to optimize performance for systems with <16GB RAM. For more information, see the [ClickHouse documentation](https://clickhouse.com/docs/operations/tips).

```yaml
clickhouse:
  customConfig:
    mark_cache_size: 524288000  # 500MB
    concurrent_threads_soft_limit_num: 1
  profiles:
    default:
      "@replace": "1"
      max_block_size: 8192
      max_download_threads: 1
      input_format_parallel_parsing: 0
      output_format_parallel_formatting: 0
```

## Values

| Key | Type | Description | Default |
| --- | ---- | ----------- | ------- |
| clickhouse.auth.enabled | bool | Enable ClickHouse authentication | `true` |
| clickhouse.auth.password | string | ClickHouse password | `"password"` |
| clickhouse.auth.skipUserSetup | bool |  | `false` |
| clickhouse.auth.username | string | ClickHouse username | `"default"` |
| clickhouse.customConfig.concurrent_threads_soft_limit_num | int |  | `1` |
| clickhouse.customConfig.mark_cache_size | int |  | `524288000` |
| clickhouse.enabled | bool | Enable ClickHouse deployment | `true` |
| clickhouse.image | object | ClickHouse image configuration | `{"repository":"clickhouse/clickhouse-server","tag":""}` |
| clickhouse.image.repository | string | ClickHouse image repository | `"clickhouse/clickhouse-server"` |
| clickhouse.image.tag | string | ClickHouse image tag - empty so it uses the tag used within the solo-owned clickhouse app version | `""` |
| clickhouse.keeper.enabled | bool | Disable ClickHouse Keeper / ZooKeeper | `false` |
| clickhouse.livenessProbe | object | Liveness probe for ClickHouse | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"tcpSocket":{"port":"http"},"timeoutSeconds":5}` |
| clickhouse.livenessProbe.failureThreshold | int | Failure threshold for liveness probe | `3` |
| clickhouse.livenessProbe.initialDelaySeconds | int | Initial delay seconds for liveness probe | `10` |
| clickhouse.livenessProbe.periodSeconds | int | Period seconds for liveness probe | `10` |
| clickhouse.livenessProbe.successThreshold | int | Success threshold for liveness probe | `1` |
| clickhouse.livenessProbe.timeoutSeconds | int | Timeout seconds for liveness probe | `5` |
| clickhouse.persistentVolume.enabled | bool | Disable persistent storage | `false` |
| clickhouse.profiles | object | User performance profiles XML | `{"default":{"@replace":"1","input_format_parallel_parsing":0,"max_block_size":8192,"max_download_threads":1,"output_format_parallel_formatting":0}}` |
| clickhouse.readinessProbe | object | Readiness probe for ClickHouse | `{"failureThreshold":3,"httpGet":{"path":"/ping","port":"http"},"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| clickhouse.readinessProbe.failureThreshold | int | Failure threshold for readiness probe | `3` |
| clickhouse.readinessProbe.initialDelaySeconds | int | Initial delay seconds for readiness probe | `10` |
| clickhouse.readinessProbe.periodSeconds | int | Period seconds for readiness probe | `10` |
| clickhouse.readinessProbe.successThreshold | int | Success threshold for readiness probe | `1` |
| clickhouse.readinessProbe.timeoutSeconds | int | Timeout seconds for readiness probe | `5` |
| clickhouse.replicasPerShard | int | Number of ClickHouse replicas | `1` |
| clickhouse.resources | object | Resource preset for ClickHouse Based on Bitnami's 2xlarge preset https://github.com/bitnami/charts/blob/0705a02b25995449285db5a830e65974ecb97385/bitnami/common/templates/_resources.tpl#L15 | `{"limits":{"cpu":6,"memory":"12288Mi"},"requests":{"cpu":1,"ephemeral-storage":"50Mi","memory":"3072Mi"}}` |
| clickhouse.shards | int | Number of ClickHouse shards | `1` |
| cluster | string | Name of the cluster where this chart is deployed | `"mgmt-cluster"` |
| global.imagePullPolicy | string | Configure image pull policy for all images in this chart | `"IfNotPresent"` |
| idp.name | string | Image name for the IDP | `"solo-enterprise-idp"` |
| idp.pullPolicy | string | Image pull policy for the IDP image | `""` |
| idp.registry | string | Container registry for the IDP image | `"us-docker.pkg.dev/solo-public"` |
| idp.repository | string | Repository path for the IDP image | `"solo-enterprise"` |
| idp.tag | string | Image tag for the IDP image | `""` |
| imagePullSecrets | list | Image pull secrets for private registries | `[]` |
| oidc.additionalScopes | list | Additional client scopes to be requested during authentication | `[]` |
| oidc.issuer | string | OIDC identity provider issuer URL This is used to discover OIDC endpoints (authorization, token, logout, etc.) via the well-known discovery endpoint: {issuer}/.well-known/openid-configuration | `""` |
| rbac.roleMapping.roleMapper | string | CEL expression to map OIDC claims to roles. Variables: 'claims', 'rolesMap' | `"claims.Groups.transformList(i, v, v in rolesMap, rolesMap[v])"` |
| rbac.roleMapping.roleMappings | object | Map of IdP groups to internal roles (global.Admin, global.Writer, global.Reader) | `{"admins":"global.Admin","readers":"global.Reader","writers":"global.Writer"}` |
| service.clusterIP | string | Cluster IP to assign to the service | `""` |
| service.type | string | Type of service to create | `"LoadBalancer"` |
| tracing.verbose | bool | Enable verbose tracing (disables strict filtering) | `false` |
| tunnelserver.livenessProbe | object | Liveness probe for tunnel server | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| tunnelserver.livenessProbe.failureThreshold | int | Failure threshold for liveness probe | `3` |
| tunnelserver.livenessProbe.initialDelaySeconds | int | Initial delay seconds for liveness probe | `10` |
| tunnelserver.livenessProbe.periodSeconds | int | Period seconds for liveness probe | `10` |
| tunnelserver.livenessProbe.successThreshold | int | Success threshold for liveness probe | `1` |
| tunnelserver.livenessProbe.timeoutSeconds | int | Timeout seconds for liveness probe | `5` |
| tunnelserver.name | string | Image name for tunnel server | `"solo-enterprise-tunnel-server"` |
| tunnelserver.pullPolicy | string | Image pull policy for the tunnel server image | `""` |
| tunnelserver.readinessProbe | object | Readiness probe for tunnel server | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| tunnelserver.readinessProbe.failureThreshold | int | Failure threshold for readiness probe | `3` |
| tunnelserver.readinessProbe.initialDelaySeconds | int | Initial delay seconds for readiness probe | `5` |
| tunnelserver.readinessProbe.periodSeconds | int | Period seconds for readiness probe | `10` |
| tunnelserver.readinessProbe.successThreshold | int | Success threshold for readiness probe | `1` |
| tunnelserver.readinessProbe.timeoutSeconds | int | Timeout seconds for readiness probe | `5` |
| tunnelserver.registry | string | Container registry for tunnel server image | `"us-docker.pkg.dev/solo-public"` |
| tunnelserver.repository | string | Repository path for the tunnel server image | `"solo-enterprise"` |
| tunnelserver.resources | object | Resources for tunnel server. If this is set by the user, it will override all defaults from values.yaml | `{"limits":{"cpu":"500m","memory":"1024Mi"},"requests":{"cpu":"250m","memory":"512Mi"}}` |
| tunnelserver.resources.limits | object | Resources for tunnel server. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the limits block. | `{"cpu":"500m","memory":"1024Mi"}` |
| tunnelserver.resources.limits.cpu | string | CPU limits for tunnel server | `"500m"` |
| tunnelserver.resources.limits.memory | string | Memory limits for tunnel server | `"1024Mi"` |
| tunnelserver.resources.requests | object | Resources for tunnel server. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the requests block. | `{"cpu":"250m","memory":"512Mi"}` |
| tunnelserver.resources.requests.cpu | string | CPU requests for tunnel server | `"250m"` |
| tunnelserver.resources.requests.memory | string | Memory requests for tunnel server | `"512Mi"` |
| tunnelserver.tag | string | Image tag for the tunnel server image | `""` |
| ui.backend.extraEnvs | object | Extra environment variables for the backend container | `{}` |
| ui.backend.livenessProbe | object | Liveness probe for the backend | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.backend.livenessProbe.failureThreshold | int | Failure threshold for liveness probe | `3` |
| ui.backend.livenessProbe.initialDelaySeconds | int | Initial delay seconds for liveness probe | `10` |
| ui.backend.livenessProbe.periodSeconds | int | Period seconds for liveness probe | `10` |
| ui.backend.livenessProbe.successThreshold | int | Success threshold for liveness probe | `1` |
| ui.backend.livenessProbe.timeoutSeconds | int | Timeout seconds for liveness probe | `5` |
| ui.backend.metricsBackendHost | string | Metrics backend host URL | `"http://localhost:8080"` |
| ui.backend.name | string | Image name for the backend | `"solo-enterprise-ui-backend"` |
| ui.backend.oidc | object | OIDC configuration for the UI backend | `{"clientId":"kagent-backend","secret":"","secretKey":"clientSecret","secretRef":"ui-backend-oidc-secret"}` |
| ui.backend.oidc.clientId | string | Name of the OIDC client that you created for token validation in the UI backend | `"kagent-backend"` |
| ui.backend.oidc.secret | string | OIDC client secret (if secretRef is not used) | `""` |
| ui.backend.oidc.secretKey | string | OIDC secret key that the secret is associated with | `"clientSecret"` |
| ui.backend.oidc.secretRef | string | Secret reference for the OIDC client secret | `"ui-backend-oidc-secret"` |
| ui.backend.pullPolicy | string | Image pull policy for the backend image | `""` |
| ui.backend.readinessProbe | object | Readiness probe for the backend | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.backend.readinessProbe.failureThreshold | int | Failure threshold for readiness probe | `3` |
| ui.backend.readinessProbe.initialDelaySeconds | int | Initial delay seconds for readiness probe | `5` |
| ui.backend.readinessProbe.periodSeconds | int | Period seconds for readiness probe | `10` |
| ui.backend.readinessProbe.successThreshold | int | Success threshold for readiness probe | `1` |
| ui.backend.readinessProbe.timeoutSeconds | int | Timeout seconds for readiness probe | `5` |
| ui.backend.registry | string | Container registry for the backend image | `"us-docker.pkg.dev/solo-public"` |
| ui.backend.repository | string | Repository path for the backend image | `"solo-enterprise"` |
| ui.backend.resources | object | Resources for the backend. If this is set by the user, it will override all defaults from values.yaml | `{"limits":{"cpu":"500m","memory":"1024Mi"},"requests":{"cpu":"250m","memory":"512Mi"}}` |
| ui.backend.resources.limits | object | Resources for the backend. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the limits block. | `{"cpu":"500m","memory":"1024Mi"}` |
| ui.backend.resources.limits.cpu | string | CPU limits for the backend | `"500m"` |
| ui.backend.resources.limits.memory | string | Memory limits for the backend | `"1024Mi"` |
| ui.backend.resources.requests | object | Resources for the backend. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the requests block. | `{"cpu":"250m","memory":"512Mi"}` |
| ui.backend.resources.requests.cpu | string | CPU requests for the backend | `"250m"` |
| ui.backend.resources.requests.memory | string | Memory requests for the backend | `"512Mi"` |
| ui.frontend.enableMockUI | bool | Enable showing mock data on the frontend | `false` |
| ui.frontend.livenessProbe | object | Liveness probe for the frontend | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.frontend.livenessProbe.failureThreshold | int | Failure threshold for liveness probe | `3` |
| ui.frontend.livenessProbe.initialDelaySeconds | int | Initial delay seconds for liveness probe | `10` |
| ui.frontend.livenessProbe.periodSeconds | int | Period seconds for liveness probe | `10` |
| ui.frontend.livenessProbe.successThreshold | int | Success threshold for liveness probe | `1` |
| ui.frontend.livenessProbe.timeoutSeconds | int | Timeout seconds for liveness probe | `5` |
| ui.frontend.name | string | Image name for the frontend | `"solo-enterprise-ui-frontend"` |
| ui.frontend.oidc | object | OIDC configuration for the frontend | `{"clientId":"kagent-ui"}` |
| ui.frontend.oidc.clientId | string | Name of the public-access OIDC client that you created for the frontend | `"kagent-ui"` |
| ui.frontend.pullPolicy | string | Image pull policy for the frontend image | `""` |
| ui.frontend.readinessProbe | object | Readiness probe for the frontend | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.frontend.readinessProbe.failureThreshold | int | Failure threshold for readiness probe | `3` |
| ui.frontend.readinessProbe.initialDelaySeconds | int | Initial delay seconds for readiness probe | `5` |
| ui.frontend.readinessProbe.periodSeconds | int | Period seconds for readiness probe | `10` |
| ui.frontend.readinessProbe.successThreshold | int | Success threshold for readiness probe | `1` |
| ui.frontend.readinessProbe.timeoutSeconds | int | Timeout seconds for readiness probe | `5` |
| ui.frontend.registry | string | Container registry for the frontend image | `"us-docker.pkg.dev/solo-public"` |
| ui.frontend.repository | string | Repository path for the frontend image | `"solo-enterprise"` |
| ui.frontend.resources | object | Resources for the frontend. If this is set by the user, it will override all defaults from values.yaml | `{"limits":{"cpu":"500m","memory":"1024Mi"},"requests":{"cpu":"250m","memory":"512Mi"}}` |
| ui.frontend.resources.limits | object | Resources for the frontend. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the limits block. | `{"cpu":"500m","memory":"1024Mi"}` |
| ui.frontend.resources.limits.cpu | string | CPU limits for the frontend | `"500m"` |
| ui.frontend.resources.limits.memory | string | Memory limits for the frontend | `"1024Mi"` |
| ui.frontend.resources.requests | object | Resources for the frontend. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the requests block. | `{"cpu":"250m","memory":"512Mi"}` |
| ui.frontend.resources.requests.cpu | string | CPU requests for the frontend | `"250m"` |
| ui.frontend.resources.requests.memory | string | Memory requests for the frontend | `"512Mi"` |
| ui.frontend.uiBackendHost | string | Backend service URL (the frontend uses "{ui-frontend-url}" if the value here is "") | `""` |
| ui.telemetryGateway.livenessProbe | object | Liveness probe for the telemetry gateway | `{"failureThreshold":3,"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.telemetryGateway.livenessProbe.failureThreshold | int | Failure threshold for liveness probe | `3` |
| ui.telemetryGateway.livenessProbe.initialDelaySeconds | int | Initial delay seconds for liveness probe | `10` |
| ui.telemetryGateway.livenessProbe.periodSeconds | int | Period seconds for liveness probe | `10` |
| ui.telemetryGateway.livenessProbe.successThreshold | int | Success threshold for liveness probe | `1` |
| ui.telemetryGateway.livenessProbe.timeoutSeconds | int | Timeout seconds for liveness probe | `5` |
| ui.telemetryGateway.pullPolicy | string | Image pull policy for telemetry gateway | `""` |
| ui.telemetryGateway.readinessProbe | object | Readiness probe for the telemetry gateway | `{"failureThreshold":3,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` |
| ui.telemetryGateway.readinessProbe.failureThreshold | int | Failure threshold for readiness probe | `3` |
| ui.telemetryGateway.readinessProbe.initialDelaySeconds | int | Initial delay seconds for readiness probe | `5` |
| ui.telemetryGateway.readinessProbe.periodSeconds | int | Period seconds for readiness probe | `10` |
| ui.telemetryGateway.readinessProbe.successThreshold | int | Success threshold for readiness probe | `1` |
| ui.telemetryGateway.readinessProbe.timeoutSeconds | int | Timeout seconds for readiness probe | `5` |
| ui.telemetryGateway.repository | string | Repository for OpenTelemetry collector image | `"otel/opentelemetry-collector-contrib"` |
| ui.telemetryGateway.resources | object | Resources for the telemetry gateway. If this is set by the user, it will override all defaults from values.yaml | `{"limits":{"cpu":"500m","memory":"1024Mi"},"requests":{"cpu":"100m","memory":"300Mi"}}` |
| ui.telemetryGateway.resources.limits | object | Resources for the telemetry gateway. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the limits block. | `{"cpu":"500m","memory":"1024Mi"}` |
| ui.telemetryGateway.resources.limits.cpu | string | CPU limits for the telemetry gateway | `"500m"` |
| ui.telemetryGateway.resources.limits.memory | string | Memory limits for the telemetry gateway | `"1024Mi"` |
| ui.telemetryGateway.resources.requests | object | Resources for the telemetry gateway. If this is set by the user, it will override all defaults from values.yaml. If this is set to null, it will not render the requests block. | `{"cpu":"100m","memory":"300Mi"}` |
| ui.telemetryGateway.resources.requests.cpu | string | CPU requests for the telemetry gateway | `"100m"` |
| ui.telemetryGateway.resources.requests.memory | string | Memory requests for the telemetry gateway | `"300Mi"` |
| ui.telemetryGateway.version | string | OpenTelemetry collector version | `"0.132.1"` |